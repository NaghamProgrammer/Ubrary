// api.js - API service for authentication and data operations

// Base API URL - adjust if your API is hosted elsewhere
const API_BASE_URL = 'http://127.0.0.1:8000/api';

// Helper to get CSRF token from cookies
function getCookie(name) {
  const cookieValue = document.cookie.match('(^|;)\\s*' + name + '\\s*=\\s*([^;]+)');
  return cookieValue ? cookieValue.pop() : '';
}

// API Service object with authentication methods
const ApiService = {
  /**
   * Register a new user
   * @param {Object} userData - User registration data (username, email, password)
   * @returns {Promise} - Promise resolving to the registration response
   */
  async register(userData) {
    try {
      // Map frontend data to backend expected format
      const apiData = {
        email: userData.email,
        password: userData.password,
        // Convert role to is_admin boolean if role is provided
        ...(userData.role && { is_admin: userData.role === 'admin' })
      };

      const response = await fetch(`${API_BASE_URL}/signup/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(apiData),
      });

      if (!response.ok) {
        try {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Registration failed');
        } catch (jsonError) {
          // If parsing JSON fails, use the status text instead
          throw new Error(`Registration failed: ${response.status} ${response.statusText}`);
        }
      }

      return await response.json();
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    }
  },

  /**
   * Login a user
   * @param {string} email - User email
   * @param {string} password - User password
   * @returns {Promise} - Promise resolving to the login response with token
   */
  async login(email, password) {
    try {
      const response = await fetch(`${API_BASE_URL}/login/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      if (!response.ok) {
        try {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Login failed');
        } catch (jsonError) {
          // If parsing JSON fails, use the status text instead
          throw new Error(`Login failed: ${response.status} ${response.statusText}`);
        }
      }

      return await response.json();
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  },

  /**
   * Request a password reset
   * @param {string} email - User email
   * @returns {Promise} - Promise resolving to the request response
   */
  async requestPasswordReset(email) {
    try {
      const response = await fetch(`${API_BASE_URL}/password-reset-request/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        try {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Password reset request failed');
        } catch (jsonError) {
          // If parsing JSON fails, use the status text instead
          throw new Error(`Password reset request failed: ${response.status} ${response.statusText}`);
        }
      }

      return await response.json();
    } catch (error) {
      console.error('Password reset request error:', error);
      throw error;
    }
  },

  /**
   * Reset a password with token
   * @param {string} uid - User ID
   * @param {string} token - Reset token
   * @param {string} newPassword - New password
   * @returns {Promise} - Promise resolving to the reset response
   */
  async resetPassword(uid, token, newPassword) {
    try {
      const response = await fetch(`${API_BASE_URL}/password-reset-confirm/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ uid, token, new_password: newPassword }),
      });

      if (!response.ok) {
        try {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Password reset failed');
        } catch (jsonError) {
          // If parsing JSON fails, use the status text instead
          throw new Error(`Password reset failed: ${response.status} ${response.statusText}`);
        }
      }

      return await response.json();
    } catch (error) {
      console.error('Password reset error:', error);
      throw error;
    }
  },

  /**
   * Logout the current user
   * @returns {Promise} - Promise resolving to the logout response
   */
  async logout() {
    try {
      // Get the auth token from storage
      const token = localStorage.getItem('authToken');
      
      if (!token) {
        throw new Error('No authentication token found');
      }

      const response = await fetch(`${API_BASE_URL}/logout/`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Token ${token}`
        }
      });

      if (!response.ok) {
        try {
          const errorData = await response.json();
          throw new Error(errorData.error || 'Logout failed');
        } catch (jsonError) {
          // If parsing JSON fails, use the status text instead
          throw new Error(`Logout failed: ${response.status} ${response.statusText}`);
        }
      }

      // Clear auth data from storage
      localStorage.removeItem('authToken');
      localStorage.removeItem('currentUser');
      sessionStorage.removeItem('currentUser');

      return await response.json();
    } catch (error) {
      console.error('Logout error:', error);
      throw error;
    }
  },

  /**
   * Get borrowed books
   * @returns {Promise} - Promise resolving to the borrowed books list
   */
  async getBorrowedBooks() {
    try {
      const response = await fetch(`${API_BASE_URL}/borrowed-books/`, {
        method: 'GET',
        credentials: 'include', 
        headers: {
          'Content-Type': 'application/json'
          // No Authorization header needed
        }
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        throw new Error(errorData?.error || `Failed to fetch borrowed books: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching borrowed books:', error);
      throw error;
    }
  },

  async returnBorrowedBook(bookId) {
    const csrfToken = getCookie('csrftoken');
    
    if (!csrfToken) {
        throw new Error('CSRF token not found. Please refresh the page or login again.');
    }

    try {
        const response = await fetch(`${API_BASE_URL}/borrowed-books/`, {
            method: 'PATCH',
            credentials: 'include',  // Important for session cookies
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken,
            },
            body: JSON.stringify({ book_id: bookId }),
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => null);
            throw new Error(errorData?.error || `Failed to return book: ${response.status} ${response.statusText}`);
        }

        return await response.json();
    } catch (error) {
        console.error('Error returning book:', error);
        throw error;
    }
},

  /**
   * Get favorite books
   * @returns {Promise} - Promise resolving to the favorite books list
   */
  async getFavoriteBooks() {
    try {
      const response = await fetch(`${API_BASE_URL}/favorite-books/`, {
        method: 'GET',
        credentials: 'include', 
        headers: {
          'Content-Type': 'application/json'
          // No Authorization header
        }
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        throw new Error(errorData?.error || `Failed to fetch favorite books: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error fetching favorite books:', error);
      throw error;
    }
  },

  /**
   * Remove a book from favorites
   * @param {string} bookId - ID of the book to remove
   * @returns {Promise} - Promise resolving to the removal response
   */
async removeFavoriteBook(bookId) {
    try {
        const csrfToken = getCookie('csrftoken');
        const response = await fetch(`${API_BASE_URL}/favorite-books/${bookId}/`, {
            method: 'DELETE',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken,
            }
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => null);
            throw new Error(errorData?.error || `Failed to remove favorite: ${response.status}`);
        }

        return await response.json();
    } catch (error) {
        console.error('Error removing favorite book:', error);
        throw error;
    }
}, async getBooks() {
    const response = await fetch(`${API_BASE_URL}/admin/books/`, {
      method: 'GET',
      credentials: 'include',
    });
    if (!response.ok) throw new Error(`Failed to get books: ${response.status}`);
    return await response.json();
  },

  async getBookById(id) {
    try {
        const response = await fetch(`${API_BASE_URL}/admin/books/${id}/`, {
            method: 'GET',
            credentials: 'include',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        if (!response.ok) {
            // Try to parse error JSON, otherwise use status text
            let errorDetail = `Book not found or error: ${response.status}`;
            try {
                const errorData = await response.json();
                errorDetail = errorData.detail || errorData.error || errorDetail;
            } catch (e) { /* Ignore JSON parse error */ }
            throw new Error(errorDetail);
        }
        const book = await response.json();
        // Ensure categories is an array if it exists
        if (book.categories && !Array.isArray(book.categories)) {
            book.categories = [book.categories]; 
        }
        return book;
    } catch (error) {
        console.error('Get book error:', error);
        throw error;
    }
  },

  async addBook(formData) {
    const csrfToken = getCookie('csrftoken');
    const response = await fetch(`${API_BASE_URL}/admin/books/`, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'X-CSRFToken': csrfToken
        // Content-Type is set automatically for FormData
      },
      body: formData
    });
    if (!response.ok) {
        let errorDetail = `Failed to add book: ${response.status}`;
        try {
            const errorData = await response.json();
            errorDetail = errorData.detail || JSON.stringify(errorData) || errorDetail;
        } catch (e) { /* Ignore JSON parse error */ }
        throw new Error(errorDetail);
    }
    return await response.json();
  },

  /**
   * Update book details
   * @param {string} id - Book ID
   * @param {object} data - Updated book data
   * @returns {Promise} - Promise resolving to updated book
   */
  async updateBook(id, data) {
    try {
        const csrfToken = getCookie('csrftoken');
        const response = await fetch(`${API_BASE_URL}/admin/books/${id}/`, {
            method: 'PUT', // Or PATCH if your backend supports partial updates
            credentials: 'include', // <<< Added this line
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrfToken
            },
            body: JSON.stringify(data)
        });

        if (!response.ok) {
            let errorDetail = `Failed to update book: ${response.status}`;
            try {
                const errorData = await response.json();
                console.error("API Error Response:", errorData); 
                // Use specific error fields if available
                errorDetail = errorData.detail || errorData.error || JSON.stringify(errorData) || errorDetail;
            } catch (e) { /* Ignore JSON parse error */ }
            throw new Error(errorDetail);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Update book error:', error);
        throw error; // Re-throw the error for the calling function to handle
    }
  },

  async deleteBook(id) {
    try {
      const response = await fetch(`${API_BASE_URL}/admin/books/${id}/`, {
        method: 'DELETE',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': getCookie('csrftoken'),
        }
      });
      if (!response.ok && response.status !== 204) { // Allow 204 No Content
        let errorDetail = `Failed to delete book: ${response.status}`;
        try {
            const errorData = await response.json();
            errorDetail = errorData.detail || errorData.error || errorDetail;
        } catch (e) { /* Ignore JSON parse error */ }
        throw new Error(errorDetail);
      }
      // For DELETE, returning the response status might be enough
      return response; 
    } catch (error) {
      console.error('Delete book error:', error);
      throw error;
    }
  },

  async getCategories() {
    try {
      const response = await fetch(`${API_BASE_URL}/categories/`, {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json'
        }
      });
      if (!response.ok) {
        throw new Error(`Failed to load categories: ${response.status}`);
      }
      return await response.json();
    } catch (error) {
      console.error('Get categories error:', error);
      throw error;
    }
  },

  /**
   * Search books by query
   * @param {string} query - Search query
   * @returns {Promise} - Promise resolving to the search results
   */
  async searchBooks(query) {
    try {
      const response = await fetch(`${API_BASE_URL}/books/?search=${encodeURIComponent(query)}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        throw new Error(errorData?.error || `Search failed: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Search error:', error);
      throw error;
    }
  },
};



// Export the API Service
window.ApiService = ApiService;
